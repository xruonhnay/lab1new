﻿using System;
using System.Collections.Generic;
using System.Data;
using MySql.Data.MySqlClient;
using MySql.Data.Types;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Owner : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            string server = "localhost";
            string database = "estore";
            string uid = "root";
            string password = "1234";
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";
            MySqlConnection cnn = new MySqlConnection(connectionString);
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM orders", cnn);
            MySqlCommand cmd1 = new MySqlCommand("SELECT * FROM delivery", cnn);
            cnn.Open();
            switch (cnn.State)

            {

                case System.Data.ConnectionState.Open:
                    {
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        MySqlDataReader dr = null;
                        dr = cmd.ExecuteReader();
                        


                        while (dr.Read())
                        {
                            string Username = (string)dr["User_name"];
                            string item = (string)dr["item_name"];
                            string bill = (string)dr["bill"];
                            string date = (string)dr["Date"];
                            string status = (string)dr["status"];
                     

                            string order = string.Format("{0} - {1} - {2} - {3} - {4}",Username,item,bill,date,status);

                            ListBox1.Items.Add(order);
                        }
                        dr.Close();
                        MySqlDataAdapter da1 = new MySqlDataAdapter(cmd1);
                        DataTable dt1 = new DataTable();
                        da1.Fill(dt1);
                        MySqlDataReader dr1 = null;
                        dr1 = cmd1.ExecuteReader();
                        while (dr1.Read())
                        {
                            string user = (string)dr1["username"];
                            string it = (string)dr1["item"];
                            string bi = (string)dr1["Bill"];
                            string dat = (string)dr1["date"];
                            string stat = (string)dr1["status"];


                            string order = string.Format("{0} - {1} - {2} - {3} - {4}", user, it,bi,dat, stat);

                            ListBox2.Items.Add(order);

                          


                        }
                        dr1.Close();
                        cnn.Close();
                        break;
                    }
                case System.Data.ConnectionState.Closed:
                    {

                        // Connection could not be made, throw an error

                        throw new Exception("The database connection state is Closed");
                        break;

                    }
            }
        }
    }

 
}