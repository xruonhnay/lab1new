﻿using System.Web.UI;

namespace WebApplication1.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}