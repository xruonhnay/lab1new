﻿using System;
using System.Collections.Generic;
using System.Data;
using MySql.Data.MySqlClient;
using MySql.Data.Types;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            string server = "localhost";
            string database = "estore";
            string uid = "root";
            string password = "1234";
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";
            MySqlConnection cnn = new MySqlConnection(connectionString);
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM  user WHERE name = '" + TextBox1.Text + "' and password = '" + TextBox2.Text + "'", cnn);
            cnn.Open();
            switch (cnn.State)

            {

                case System.Data.ConnectionState.Open:
                    {
                        MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        MySqlDataReader dr = null;
                        dr = cmd.ExecuteReader();
                        if (dr.Read())
                        {
                            if (TextBox1.Text.ToString() == dr["name"].ToString() && TextBox2.Text.ToString() == dr["password"].ToString())
                            {
                                if (TextBox1.Text.ToString() == "owner" && TextBox2.Text.ToString()== "0101") 
                                {
                                    Response.Redirect("Owner.aspx");

                                }
                                else {
                                    Response.Write("<script>alert('Login successful. Please enter your details again.');</script>");
                                    Response.Redirect("Menu.aspx");
                                }
                            }


                            else if (TextBox1.Text.ToString() != dr["name"].ToString() || TextBox2.Text.ToString() != dr["password"].ToString())
                            {
                                Response.Write("<script>alert('login not successful');</script>");
                            }

                        }



                        dr.Close();
                        cnn.Close();
                        break;
                    }
                case System.Data.ConnectionState.Closed:
                    {

                        // Connection could not be made, throw an error

                        throw new Exception("The database connection state is Closed");
                        break;

                    }
            }
        }
    }

}
    
