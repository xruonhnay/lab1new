﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace LIBRARY_MANAGEMENT_SYSTEM
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
       
        private void Button1_Click(object sender, EventArgs e)
        {
            ListBox listBox1 = new ListBox();
            // Set the size and location of the ListBox.
            listBox1.Size = new System.Drawing.Size(200, 100);
            listBox1.Location = new System.Drawing.Point(10, 10);
            // Add the ListBox to the form.
            this.Controls.Add(listBox1);
            // Set the ListBox to display items in multiple columns.
            listBox1.MultiColumn = true;
            // Set the selection mode to multiple and extended.
            listBox1.SelectionMode = SelectionMode.MultiExtended;

            // Shutdown the painting of the ListBox as items are added.
            listBox1.BeginUpdate();

            //string server = "localhost";
           // string database = "lab2sc";
            //string uid = "root";
           // string password = "bitch135";
            string connectionString;
            connectionString = "datasource=127.0.0.1;port=3306;username=root;password=bitch135;database=lab2sc;";
            MySqlConnection cnn = new MySqlConnection(connectionString);
            try
            {
                cnn.Open();



                MySqlCommand cmd = new MySqlCommand("SELECT * FROM books ", cnn);

                MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                MySqlCommand cmdd = new MySqlCommand("SELECT * FROM dvd ", cnn);

                MySqlDataAdapter daa = new MySqlDataAdapter(cmdd);
                MySqlCommand cmddd = new MySqlCommand("SELECT * FROM journals ", cnn);

                MySqlDataAdapter daaa = new MySqlDataAdapter(cmddd);
                DataTable dt = new DataTable();
                DataTable dtt = new DataTable();
                DataTable dttt = new DataTable();
                da.Fill(dt);
                daa.Fill(dtt);
                daaa.Fill(dttt);

                MySqlDataReader dr = null;
                dr = cmd.ExecuteReader();
                MySqlDataReader drr = null;
                drr = cmdd.ExecuteReader();
                MySqlDataReader drrr = null;
                drrr = cmddd.ExecuteReader();
                if (dr.HasRows)
                {

                    while (dr.Read())
                    {
                        string[] row = { dr.GetString(0), dr.GetString(1), dr.GetString(2), dr.GetString(3),
                                         dr.GetString(4), dr.GetString(5), dr.GetString(6), dr.GetString(7), dr.GetString(8), dr.GetString(9), dr.GetString(10), };
                        listBox1.Items.Add(row[1] + "            " + row[5] + "       " + row[2] + " by " + row[3] + " is " + row[10]);
                       

                    }
                }
                else
                {
                    Console.WriteLine("No rows found.");
                }
                if (drr.HasRows)
                {

                    while (drr.Read())
                    {
                        string[] row = { drr.GetString(0), drr.GetString(1), drr.GetString(2), drr.GetString(3),
                                         drr.GetString(4), drr.GetString(5), drr.GetString(6), drr.GetString(7), drr.GetString(8), drr.GetString(9), drr.GetString(10), };
                        listBox1.Items.Add(row[1] + "            " + row[5] + "       " + row[2] + " by " + row[3] + " is " + row[10]);
      

                    }
                }
                else
                {
                    Console.WriteLine("No rows found.");
                }
                if (drrr.HasRows)
                {

                    while (drrr.Read())
                    {
                        string[] row = { drrr.GetString(0), drrr.GetString(1), drrr.GetString(2), drrr.GetString(3),
                                         drrr.GetString(4), drrr.GetString(5), drrr.GetString(6), drrr.GetString(7), drrr.GetString(8), drrr.GetString(9), drrr.GetString(10), };
                        listBox1.Items.Add(row[1] + "            " + row[5] + "       " + row[2] + " by " + row[3] + " is " + row[10]);
                        // allRecordsListBox.Items.Add(row[2]);

                    }
                }
                else
                {
                    Console.WriteLine("No rows found.");
                }

                cnn.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("Can not open Database ! ");
            }

        }
        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Search_Click(object sender, EventArgs e)
        {
            ListBox listBox1 = new ListBox();
            string Title = textBox1.Text;
            string Author = textBox2.Text;
            string Genre = textBox3.Text;
            string a = string.Format("Select * from artifacts where Name= '{0}'", Title);
            string b = string.Format("Select * from artifacts where Author= '{0}'", Author);
            string c = string.Format("Select * from artifacts where Genre= '{0}'", Genre);
            string server = "localhost";
            string database = "lab2sc";
            string uid = "root";
            string password = "bitch135";
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" +
            database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";
            MySqlConnection cnn = new MySqlConnection(connectionString);
            MySqlCommand commandDatabase1 = new MySqlCommand(a, cnn);
            MySqlCommand commandDatabase2 = new MySqlCommand(b, cnn);
            MySqlCommand commandDatabase3 = new MySqlCommand(c, cnn);
            try
            {
                cnn.Open();
                MySqlDataReader reader = commandDatabase1.ExecuteReader();
                MySqlDataReader reader2 = commandDatabase2.ExecuteReader();
                MySqlDataReader reader3 = commandDatabase3.ExecuteReader();
                // Success, now list 

                // If there are available rows
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {

                        Console.WriteLine(reader.GetString(0) + " - " + reader.GetString(1) + " - " + reader.GetString(2) + " - " + reader.GetString(3) + " - " + reader.GetString(4) + " - " + reader.GetString(5) + " - " + reader.GetString(6) + " - " + reader.GetString(7) + " - " + reader.GetString(8) + " - " + reader.GetString(9));
                        listBox1.Items.Add(reader.GetString(0) + " - " + reader.GetString(1) + " - " + reader.GetString(2) + " - " + reader.GetString(3) + " - " + reader.GetString(4) + " - " + reader.GetString(5) + " - " + reader.GetString(6) + " - " + reader.GetString(7) + " - " + reader.GetString(8) + " - " + reader.GetString(9));

                        string q = reader.GetString(8);
                        int res = String.Compare(q, "0");
                        if (res == 0)
                        {
                            Console.Write("This book isnt available");
                            listBox1.Items.Add(" \n This book isnt available");
                        }

                        else
                        {
                            Console.Write("This book is available");
                            listBox1.Items.Add(" \n This book is available");

                        }
                    }
                }
                else
                {
                    Console.WriteLine("No rows found.");
                }
                if (reader2.HasRows)
                {
                    while (reader2.Read())
                    {

                        Console.WriteLine(reader2.GetString(0) + " - " + reader2.GetString(1) + " - " + reader2.GetString(2) + " - " + reader2.GetString(3) + " - " + reader2.GetString(4) + " - " + reader2.GetString(5) + " - " + reader2.GetString(6) + " - " + reader2.GetString(7) + " - " + reader2.GetString(8) + " - " + reader2.GetString(9));
                        listBox1.Items.Add(reader2.GetString(0) + " - " + reader2.GetString(1) + " - " + reader2.GetString(2) + " - " + reader2.GetString(3) + " - " + reader2.GetString(4) + " - " + reader2.GetString(5) + " - " + reader2.GetString(6) + " - " + reader2.GetString(7) + " - " + reader2.GetString(8) + " - " + reader2.GetString(9));

                        string q = reader2.GetString(8);
                        int res = String.Compare(q, "0");
                        if (res == 0)
                        {
                            Console.Write("This book isnt available");
                            listBox1.Items.Add(" \n This book isnt available");
                        }

                        else
                        {
                            Console.Write("This book is available");
                            listBox1.Items.Add(" \n This book is available");

                        }
                    }
                }
                else
                {
                    Console.WriteLine("No rows found.");
                }
                if (reader3.HasRows)
                {
                    while (reader3.Read())
                    {

                        Console.WriteLine(reader3.GetString(0) + " - " + reader3.GetString(1) + " - " + reader3.GetString(2) + " - " + reader3.GetString(3) + " - " + reader3.GetString(4) + " - " + reader3.GetString(5) + " - " + reader3.GetString(6) + " - " + reader3.GetString(7) + " - " + reader3.GetString(8) + " - " + reader3.GetString(9));
                        listBox1.Items.Add(reader3.GetString(0) + " - " + reader3.GetString(1) + " - " + reader3.GetString(2) + " - " + reader3.GetString(3) + " - " + reader3.GetString(4) + " - " + reader3.GetString(5) + " - " + reader3.GetString(6) + " - " + reader3.GetString(7) + " - " + reader3.GetString(8) + " - " + reader3.GetString(9));

                        string q = reader3.GetString(8);
                        int res = String.Compare(q, "0");
                        if (res == 0)
                        {
                            Console.Write("This book isnt available");
                            listBox1.Items.Add(" \n This book isnt available");
                        }

                        else
                        {
                            Console.Write("This book is available");
                            listBox1.Items.Add(" \n This book is available");

                        }
                    }
                }
                else
                {
                    Console.WriteLine("No rows found.");
                }
                cnn.Close();
            }
            catch (Exception)
            {
                Console.WriteLine("Cant open database!!");
            }
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }
    }
}
